namespace ViewComponentSample
{
	using System;
	using System.Web;

	public class GlobalApplication : HttpApplication
	{
		public GlobalApplication()
		{
		}

		public void Application_OnStart()
		{
		}

		public void Application_OnEnd() 
		{
		}
	}
}
