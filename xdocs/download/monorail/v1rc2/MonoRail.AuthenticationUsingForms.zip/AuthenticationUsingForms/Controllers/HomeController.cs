namespace AuthenticationUsingForms.Controllers
{
	using System;

	using Castle.MonoRail.Framework;

	[Layout("default")]
	public class HomeController : SmartDispatcherController
	{
		public void Index()
		{
		}
	}
}
